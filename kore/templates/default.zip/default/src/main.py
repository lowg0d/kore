from kore import Interface
from PySide6.QtCore import QObject, QThread, Signal

from .gui.views import Ui_MainWindow


class MainWindow(Interface):

    def __init__(self, app_data):
        super().__init__(app_data)

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.ui.versionlabel.setText(f"v{self.version}")
        self.show()

        self.theme = False
        self.apply_theme("dark")

        self.ui.switch_theme_btn.clicked.connect(self.toggle_theme)

    def toggle_theme(self):
        ## example theme logic
        self.theme = not self.theme
        if self.theme:
            self.apply_theme("light")
        else:
            self.apply_theme("dark")

    def apply_theme(self, name: str):
        with open(f"./src/gui/assets/themes/{name}.qss", "r") as f:
            theme_data = f.read()
            self.apply_style(theme_data)
