# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_window.ui'
##
## Created by: Qt User Interface Compiler version 6.7.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QMainWindow, QPushButton, QSizePolicy, QSpacerItem,
    QStackedWidget, QVBoxLayout, QWidget)
from src.gui.assets import src_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(754, 474)
        MainWindow.setMouseTracking(False)
        MainWindow.setStyleSheet(u"")
        MainWindow.setAnimated(False)
        MainWindow.setUnifiedTitleAndToolBarOnMac(True)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setMinimumSize(QSize(600, 400))
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.centralframe = QFrame(self.centralwidget)
        self.centralframe.setObjectName(u"centralframe")
        self.centralframe.setFrameShape(QFrame.Shape.NoFrame)
        self.centralframe.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.centralframe)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 30, 0, 0)
        self.centralStackedWidget = QStackedWidget(self.centralframe)
        self.centralStackedWidget.setObjectName(u"centralStackedWidget")
        self.mainPage = QWidget()
        self.mainPage.setObjectName(u"mainPage")
        self.verticalLayout_3 = QVBoxLayout(self.mainPage)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.mainPageFrame = QFrame(self.mainPage)
        self.mainPageFrame.setObjectName(u"mainPageFrame")
        self.mainPageFrame.setFrameShape(QFrame.Shape.NoFrame)
        self.mainPageFrame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.mainPageFrame)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.topFrame = QFrame(self.mainPageFrame)
        self.topFrame.setObjectName(u"topFrame")
        self.topFrame.setFrameShape(QFrame.Shape.StyledPanel)
        self.topFrame.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.topFrame)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.helloworld_label = QLabel(self.topFrame)
        self.helloworld_label.setObjectName(u"helloworld_label")
        self.helloworld_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_2.addWidget(self.helloworld_label)


        self.verticalLayout_4.addWidget(self.topFrame)

        self.frame_2 = QFrame(self.mainPageFrame)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame_2)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.horizontalSpacer_2 = QSpacerItem(274, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_2)

        self.switch_theme_btn = QPushButton(self.frame_2)
        self.switch_theme_btn.setObjectName(u"switch_theme_btn")
        self.switch_theme_btn.setMinimumSize(QSize(200, 33))
        self.switch_theme_btn.setMaximumSize(QSize(200, 33))
        self.switch_theme_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))

        self.horizontalLayout_3.addWidget(self.switch_theme_btn)

        self.horizontalSpacer = QSpacerItem(274, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer)


        self.verticalLayout_4.addWidget(self.frame_2)


        self.verticalLayout_3.addWidget(self.mainPageFrame)

        self.statusBarFrame = QFrame(self.mainPage)
        self.statusBarFrame.setObjectName(u"statusBarFrame")
        self.statusBarFrame.setMinimumSize(QSize(0, 15))
        self.statusBarFrame.setMaximumSize(QSize(16777215, 15))
        self.statusBarFrame.setFrameShape(QFrame.Shape.NoFrame)
        self.statusBarFrame.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout = QHBoxLayout(self.statusBarFrame)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(8, 0, 8, 0)
        self.spacer_statusbar = QSpacerItem(710, 12, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout.addItem(self.spacer_statusbar)

        self.versionlabel = QLabel(self.statusBarFrame)
        self.versionlabel.setObjectName(u"versionlabel")

        self.horizontalLayout.addWidget(self.versionlabel)


        self.verticalLayout_3.addWidget(self.statusBarFrame)

        self.centralStackedWidget.addWidget(self.mainPage)

        self.verticalLayout_2.addWidget(self.centralStackedWidget)


        self.verticalLayout.addWidget(self.centralframe)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.helloworld_label.setText(QCoreApplication.translate("MainWindow", u"Hello World !", None))
        self.switch_theme_btn.setText(QCoreApplication.translate("MainWindow", u"Switch Theme", None))
        self.versionlabel.setText(QCoreApplication.translate("MainWindow", u"v0.1.0", None))
    # retranslateUi

