from .dotpy.main_window import Ui_MainWindow
